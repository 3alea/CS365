﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FocusedCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset;
    public Vector3 target_offset;
    public float rotation_speed;
    float yaw;
    // Start is called before the first frame update
    void Start()
    {
        yaw = 0.0f;
        target.position += target_offset;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        yaw += Input.GetAxis("Mouse X");
        Vector3 desired_position = target.position + offset - target_offset;
        transform.position = desired_position;        
        transform.LookAt(target);
        transform.RotateAround(target.position, Vector3.up, yaw*rotation_speed);
    }
}
